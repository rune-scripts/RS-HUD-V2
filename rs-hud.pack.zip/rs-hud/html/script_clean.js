const CONFIG = {
    normal: {
        x: 0.40,
        y: 0.98,
        width: 0.08,
        height: -1.5
    },
    bigmap: {
        x: 0.15,
        y: 0.20,
        width: 0.0,
        height: 0.0
    }
};

const elements = {
    wrapper: document.getElementById('hud-wrapper'),
    container: document.getElementById('status-bars'),
    elLeft: document.getElementById('top-left'),
    elRight: document.getElementById('top-right'),
    rootStyle: document.documentElement.style
};

const barCache = new Map();

function getBarElements(name) {
    let cached = barCache.get(name);
    if (!cached) {
        let fill = document.getElementById(`${name}-bar`);
        let bg;

        if (!fill) {
            bg = document.createElement('div');
            bg.className = 'bar-bg';

            fill = document.createElement('div');
            fill.className = 'bar-fill';
            fill.id = `${name}-bar`;

            bg.appendChild(fill);
            elements.container.appendChild(bg);
        } else {
            bg = fill.parentElement;
        }

        cached = { fill, bg, lastWidth: null };
        barCache.set(name, cached);
    }
    return cached;
}

window.addEventListener('message', function(event) {
    const data = event.data;
    if (!data) return;

    if (data.action === 'updateHud') {
        const isHidden = data.hidden ? 'none' : 'block';
        if (elements.wrapper.style.display !== isHidden) {
            elements.wrapper.style.display = isHidden;
        }

        if (data.hidden) return;

        if (Array.isArray(data.bars)) {
            for (let i = 0; i < data.bars.length; i++) {
                const bar = data.bars[i];
                const node = getBarElements(bar.name);

                const val = Math.min(100, Math.max(0, bar.value));
                const newWidth = `${val}%`;

                if (node.lastWidth !== newWidth) {
                    node.fill.style.width = newWidth;
                    node.fill.style.setProperty('--bar-color', bar.color);
                    node.bg.style.display = val <= 0 ? 'none' : 'block';
                    node.lastWidth = newWidth;
                }
            }
        }

        const newLeft = data.topLeft || 'Unknown';
        const newRight = data.topRight || '';

        if (elements.elLeft.textContent !== newLeft) elements.elLeft.textContent = newLeft;
        if (elements.elRight.textContent !== newRight) elements.elRight.textContent = newRight;
    }

    if (data.action === 'updateMinimap') {
        if (data.colormap) {
            elements.rootStyle.setProperty('--primary', data.colormap.Primary);
            elements.rootStyle.setProperty('--secondary', data.colormap.Secondary);
        }

        const offset = data.isBigmap ? CONFIG.bigmap : CONFIG.normal;
        const style = elements.wrapper.style;

        style.left = `${data.left * 100 + offset.x}%`;
        style.top = `${data.top * 100 + offset.y}%`;
        style.width = `${data.width * 100 + offset.width}%`;
        style.height = `${data.height * 100 + offset.height}%`;
    }
});