fx_version 'cerulean'
game 'gta5'

author "RUNE SCRIPTS"
description "A simple, modern and optimized HUD displaying any data you want with a simple config."
version "1.0.0"
lua54 "yes"

client_scripts {
    'config.lua',
    'client.lua'
}

ui_page 'html/ui.html'

files {
    'html/ui.html',
    'html/style.css',
    'html/script.js',
    'stream/*.ytd',
    'stream/*.gfx'
}

data_file "SCALEFORM_DLC_FILE" "stream/*.gfx"

escrow_ignore {
    'config.lua'
}
dependency '/assetpacks'